
#ifndef PROTOCOL_H_
#define PROTOCOL_H_

#define MAXBUFF 512
#define PROTOPORT 56700 // default port
#define SERVERNAME "localhost" //default server name

#endif /* PROTOCOL_H_ */
